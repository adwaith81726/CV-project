import cv2
import numpy as np

print("✅ OpenCV and NumPy are working correctly in VS Code!")
print("OpenCV version:", cv2.__version__)
print("NumPy version:", np.__version__)
